import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { signOut, getAuth } from '@angular/fire/auth';
import {  AuthService } from '../service/auth.service';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { Router } from '@angular/router';
import { async } from '@firebase/util';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
   loginUsuario:FormGroup;
   

  constructor(private fb:FormBuilder, 
    afAuth : AngularFireAuth, 
    private router:Router)
     {
   this.loginUsuario= this.fb.group({
    email:["",Validators.required],
    password:["",Validators.required],

   });
   

   }

  ngOnInit(): void {}

 login() {
  const email=this.loginUsuario.value.email;
  const password=this.loginUsuario.value.password;
  console.log(email,password);
 
 
  
    
   
  
 }

  Logout() {
  
  //---//
const auth = getAuth();
signOut(auth).then(() => {
 console.log("Saliendo.."); // Sign-out successful.
}).catch((error) => { console.log(error);
  // An error happened.
});
  ///-------///
}




  }
















