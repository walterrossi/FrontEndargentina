import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-acerca-img',
  templateUrl: './modal-acerca-img.component.html',
  styleUrls: ['./modal-acerca-img.component.css']
})
export class ModalAcercaImgComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
