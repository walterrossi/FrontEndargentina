import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AcercaEditComponent } from './acerca-edit/acerca-edit.component';
import { EducacionEditComponent } from './educacion-edit/educacion-edit.component';
import { EncabezadoComponent } from './encabezado/encabezado.component';
import { ExperienciaEditComponent } from './experiencia-edit/experiencia-edit.component';
import { HomeComponent } from './home/home.component';
import { IniciarSesionComponent } from './iniciar-sesion/iniciar-sesion.component';
import { ModalAcercaComponent } from './modal-acerca/modal-acerca/modal-acerca.component';
import { MusicComponent } from './music/music.component';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { ProyectoComponent } from './proyecto/proyecto.component';


import { HardEditComponent} from './hard-edit/hard-edit.component';
import { ModalEncabezadoComponent } from './modal-encabezado/modal-encabezado.component';
import { ModalExperienciaComponent } from './modal-experiencia/modal-experiencia.component';
import { NgModelGroup } from '@angular/forms';
import { ModalEducacionComponent } from './modal-educacion/modal-educacion.component';
import { ModalEncabezadoNombreComponent } from './modal-encabezado-nombre/modal-encabezado-nombre.component';
import { ModalProyectoComponent } from './modal-proyecto/modal-proyecto.component';
import { ModalHtmlComponent } from './modal-html/modal-html.component';
import { ModalExperienciaImgComponent } from './modal-experiencia-img/modal-experiencia-img.component';
import { ModalEducacionImgComponent } from './modal-educacion-img/modal-educacion-img.component';
import { ModalProyectoImgComponent } from './modal-proyecto-img/modal-proyecto-img.component';
import { LoginComponent } from './login/login.component';





const routes: Routes = [
  { path:'',redirectTo: "portfolio", pathMatch:'full'},//sacarla    
  { path: "portfolio", component: PortfolioComponent },
  { path: "iniciar-sesion", component: IniciarSesionComponent },
  { path: "home", component:HomeComponent},
  { path: "login", component:LoginComponent},
 
 
  { path: "music", component:MusicComponent},
  { path: "acerca-edit", component:AcercaEditComponent},
  { path: "educacion-edit", component:EducacionEditComponent},
  { path: "modal-acerca", component:ModalAcercaComponent},
  { path: "experiencia-edit", component:ExperienciaEditComponent},
  
  { path: "modal-encabezado", component: ModalEncabezadoComponent},
  { path: "modal-experiencia", component: ModalExperienciaComponent},
  { path: "modal-educacion",component: ModalEducacionComponent},
  { path: "modal-encabezado-nombre",component: ModalEncabezadoNombreComponent},
  { path: "modal-proyecto", component: ModalProyectoComponent},
  { path: "modal-html", component: ModalHtmlComponent},
  { path: "modal-experiencia-img", component: ModalExperienciaImgComponent},
  { path: "modal-educacion-img", component: ModalEducacionImgComponent},
  { path: "modal-proyecto-img", component: ModalProyectoImgComponent},
  
  
  { path:'**',redirectTo: "portfolio", pathMatch:'full'} // si pones cualquier url diferente va a portfolio 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],  //cualquier cosa quitar use hashfirebase login
  exports: [RouterModule]
})
export class AppRoutingModule { }
