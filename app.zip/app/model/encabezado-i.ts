export interface encabezadoi {
    nombre: String;
    apellido: String;
}
