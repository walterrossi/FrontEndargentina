import { Component, OnInit } from '@angular/core';
import { AuthService } from '../service/auth.service';
import { getAuth, signOut,onAuthStateChanged } from "firebase/auth";
import { UserService } from '../service/user.service';
import { Router } from '@angular/router';




@Component({
  selector: 'app-iniciar-sesion',
  templateUrl: './iniciar-sesion.component.html',
  styleUrls: ['./iniciar-sesion.component.css']
})
export class IniciarSesionComponent{
  
  usuario = {
  email:'',
  password:''

///agregue esto///

///




 }
  constructor(private user:UserService, private authService:AuthService, private router: Router) {

  }

  Ingresar(){ 

//// tenia desde aca///
    console.log(this.usuario); 
    const {email,password} = this.usuario;

   

    this.authService.login(email,password).then(res=> {
    
      console.log("Se logueo: ",res);
      
      console.log("El email: ",email);
      console.log("El password: ",password);
      this.router.navigateByUrl('portfolio'); 
     // console.log(this.authService.afAuth.currentUser);
   }) .catch(error=>{ console.log("No Se logueo... ");
   } );
  
      

   
 }
 //habilitar hasta aca//
   
       

   
   
    
  

  Logout() {
  
  //---//
const auth = getAuth();
signOut(auth).then(() => {
 console.log("Saliendo.."); // Sign-out successful.
}).catch((error) => {
  // An error happened.
});
  ///-------///
  
  }
}





  

  
 







